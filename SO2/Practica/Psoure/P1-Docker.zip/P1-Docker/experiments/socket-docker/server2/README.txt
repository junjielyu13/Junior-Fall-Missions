 
docker build -t server2 .
docker run -p 4000:5000 server2

