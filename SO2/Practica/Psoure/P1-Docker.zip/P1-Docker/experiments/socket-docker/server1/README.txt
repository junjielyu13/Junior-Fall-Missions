 
docker build -t server1 .
docker run -p 3000:5000 server1

