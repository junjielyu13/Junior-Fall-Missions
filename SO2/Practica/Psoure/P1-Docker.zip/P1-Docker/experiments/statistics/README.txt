
docker build -t statistics .
docker run -ti statistics
